package com.upload.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.upload.entity.details;

public interface detailsRepository extends JpaRepository<details, Long>{

	 

}
