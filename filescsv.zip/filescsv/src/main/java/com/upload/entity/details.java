package com.upload.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tabledetails")
public class details {
	
	@Id
	@Column(name="id")
	private long id;
	@Column(name="username")
	private String username;
	@Column(name="filename")
	private String filename;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public details(long id, String username, String filename) {
		super();
		this.id = id;
		this.username = username;
		this.filename = filename;
	}
	public details() {
		//super();
		// TODO Auto-generated constructor stub
	}
	
}
