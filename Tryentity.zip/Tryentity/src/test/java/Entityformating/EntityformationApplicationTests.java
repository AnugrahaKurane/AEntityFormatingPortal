package Entityformating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntityformationApplicationTests {

	@Test
	void contextLoads() {
	}

}
