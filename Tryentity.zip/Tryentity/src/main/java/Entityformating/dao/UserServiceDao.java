package Entityformating.dao;

import java.util.List;

import Entityformating.entites.User;

public interface UserServiceDao {
	
	public List<User> findAll(String emailId,String password);

}
