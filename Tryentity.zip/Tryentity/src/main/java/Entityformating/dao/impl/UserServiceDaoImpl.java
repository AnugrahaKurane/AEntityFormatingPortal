package Entityformating.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Entityformating.dao.UserServiceDao;
import Entityformating.entites.User;
import Entityformating.entites.UserRepo;

@Repository
public class UserServiceDaoImpl implements UserServiceDao{


	@Autowired
	UserRepo repo;
	@Override
	public List<User> findAll(String emailId, String password) {
		return repo.findAll(emailId, password);
	}
}
