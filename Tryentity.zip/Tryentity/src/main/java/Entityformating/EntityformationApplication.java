package Entityformating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import Entityformating.entites.User;

@SpringBootApplication
public class EntityformationApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(EntityformationApplication.class, args);
		
		
		//ApplicationContext context=SpringApplication.run(EntityformationApplication.class, args);
		
		//UserRepo UserRepo=context.getBean(UserRepo.class);
		
//		User user=new User();
//		user.setId(1);
//		user.setEmailID("anu@gmail.com");
//		user.setPassword("1233");
//		
//		User user1=UserRepo.save(user);
//		
//		System.out.println(user1);
//		
		
	}

}
