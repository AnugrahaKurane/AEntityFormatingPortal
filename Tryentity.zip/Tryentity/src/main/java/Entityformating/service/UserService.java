package Entityformating.service;

public interface UserService {

	boolean findAll(String emailId, String password);

	
}
