package Entityformating.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Entityformating.dao.UserServiceDao;
import Entityformating.entites.User;
import Entityformating.service.UserService;

@Service
public class UserServiceImpl implements UserService{
		@Autowired
		UserServiceDao userServiceDao;
		@Override
		public boolean findAll(String emailId, String password) {
			List<User> listUser=   userServiceDao.findAll(emailId, password);

			if(listUser.isEmpty())
				return false;
			else
				return true;
		}


}
