package Entityformating.entites;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import Entityformating.entites.User;

public interface UserRepo extends JpaRepository<User, Long> {
	
	@Query("SELECT u FROM User u WHERE u.emailId=?1 and u.password=?2")
	public List<User> findAll (String emailId,String password);

}
