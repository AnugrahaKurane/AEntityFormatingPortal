package Entityformating.entites;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import Entityformating.service.UserService;


@RestController
public class validate {
	
	@Autowired
	UserService userService;
	
	@GetMapping("/EF/{emailId}/{password}")
	public boolean validate(@PathVariable String emailId,@PathVariable String password) {
		return userService.findAll(emailId, password);
	}

}
