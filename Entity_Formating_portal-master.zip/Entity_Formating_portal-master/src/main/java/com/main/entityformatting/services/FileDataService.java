package com.main.entityformatting.services;

import java.util.List;

import com.main.entityformatting.entity.Filedata;

public interface FileDataService {
    public void save(List<Filedata> list);
}
