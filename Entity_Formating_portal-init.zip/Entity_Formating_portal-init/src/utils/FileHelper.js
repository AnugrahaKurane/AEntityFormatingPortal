export const config = {
  date: ["DD MMM YYYY", "MMM DD YYYY"],
  amount: ["INR", "USD"],
  cost: ["Round Up", "Round Down"],
  name: ["Lowercase", "Uppercase"],
  discount: ["Percentage"],
};
